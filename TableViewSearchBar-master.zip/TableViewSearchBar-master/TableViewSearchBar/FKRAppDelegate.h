//
//  FKRAppDelegate.h
//  TableViewSearchBar
//
//  Created by Fabian Kreiser on 10.02.13.
//  Copyright (c) 2013 Fabian Kreiser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKRAppDelegate : UIResponder <UIApplicationDelegate> {
    
}

@property(nonatomic, strong) UINavigationController *navigationController;

@end